#include <iostream>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <string.h>
#include <cstring>
#include <assert.h>

#define INT_MAX 2147483647
#define INT_MIN -2147483647

using namespace std;

const int magicSquare[3][3] = { {8,1,6}, {3,5,7}, {4,9,2} };
const int scorePerGrid = 5;

int getOpponent(int player)
{
	assert(player == 1 || player == 2);
	return !(player - 1) + 1;
}

class board {
public:
	int field[3][3][3][3];
	int macroBoard[3][3];
	int score;

	board* copy();
	
	void play_move(int player, int fieldX, int fieldY);
	void evaluateScore();
	
	int getWinner() { return winner; }
	int evaluateMoveCount();
	int getMoveCount() { return moveCount; }
	int getScore(int player);

private:
	int winner = 0;
	int moveCount = 0;
	void evaluateMacroboard(int gridX, int gridY, int x, int y);
	void evaluateWinner(int gridX, int gridY);
};

board* board::copy()
{
	board* b = new board();
	memcpy(b, this, sizeof(board));
	return b;
}

void board::play_move(int player, int fieldX, int fieldY)
{
	int opponent = getOpponent(player);
	int x = fieldX % 3;
	int y = fieldY % 3;
	int gridX = fieldX / 3;
	int gridY = fieldY / 3;
	assert(macroBoard[gridX][gridY] == -1); //Grid must be playable
	assert(field[gridX][gridY][x][y] == 0); //board must be open at spot
	field[gridX][gridY][x][y] = player;
	evaluateMacroboard(gridX, gridY, x, y); //Check if grid has been won
	if (macroBoard[gridX][gridY] > 0)
	{
		evaluateWinner(gridX, gridY);

		field[gridX][gridY][x][y] = 0; //Temporarily reset the move back to 0, so the grid's score can be subtracted
		int subtractScore = 0;
		for (int boxY = 0; boxY < 3; ++boxY)
		{
			for (int boxX = 0; boxX < 3; ++boxX)
			{
				if (field[gridX][gridY][boxX][boxY] == 1)
				{
					if (field[gridX][gridY][(boxX + 1) % 3][boxY] != 2 && field[gridX][gridY][(boxX + 2) % 3][boxY] != 2)
					{
						subtractScore++;
					}

					if (field[gridX][gridY][boxX][(boxY + 1) % 3] != 2 && field[gridX][gridY][boxX][(boxY + 2) % 3] != 2)
					{
						subtractScore++;
					}

					if (boxX == boxY && field[gridX][gridY][(boxX + 1) % 3][(boxY + 1) % 3] != 2 && field[gridX][gridY][(boxX + 2) % 3][(boxY + 2) % 3] != 2)
					{
						subtractScore++;
					}

					if (boxX == 2 - boxY && field[gridX][gridY][(boxX + 2) % 3][(boxY + 1) % 3] != 2 && field[gridX][gridY][(boxX + 1) % 3][(boxY + 2) % 3] != 2)
					{
						subtractScore++;
					}
				}
				else if (field[gridX][gridY][boxX][boxY] == 2)
				{
					if (field[gridX][gridY][(boxX + 1) % 3][boxY] != 1 && field[gridX][gridY][(boxX + 2) % 3][boxY] != 1)
					{
						subtractScore--;
					}

					if (field[gridX][gridY][boxX][(boxY + 1) % 3] != 1 && field[gridX][gridY][boxX][(boxY + 2) % 3] != 1)
					{
						subtractScore--;
					}

					if (boxX == boxY && field[gridX][gridY][(boxX + 1) % 3][(boxY + 1) % 3] != 1 && field[gridX][gridY][(boxX + 2) % 3][(boxY + 2) % 3] != 1)
					{
						subtractScore--;
					}

					if (boxX == 2 - boxY && field[gridX][gridY][(boxX + 2) % 3][(boxY + 1) % 3] != 1 && field[gridX][gridY][(boxX + 1) % 3][(boxY + 2) % 3] != 1)
					{
						subtractScore--;
					}
				}
			}
		}
		field[gridX][gridY][x][y] = player;
		score -= subtractScore;

		if (macroBoard[gridX][gridY] == 3)
		{
			if (macroBoard[(gridX + 1) % 3][gridY] == opponent)
				score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
			else if (macroBoard[(gridX + 1) % 3][gridY] == player)
				score += opponent == 1 ? scorePerGrid : -scorePerGrid;

			if (macroBoard[(gridX + 2) % 3][gridY] == opponent)
				score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
			if (macroBoard[(gridX + 2) % 3][gridY] == player)
				score += opponent == 1 ? scorePerGrid : -scorePerGrid;
			

			if (macroBoard[gridX][(gridY + 1) % 3] == opponent)
				score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
			if (macroBoard[gridX][(gridY + 1) % 3] == player)
				score += opponent == 1 ? scorePerGrid : -scorePerGrid;

			if (macroBoard[gridX][(gridY + 2) % 3] == opponent)
				score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
			if (macroBoard[gridX][(gridY + 2) % 3] == player)
				score += opponent == 1 ? scorePerGrid : -scorePerGrid;

			if (gridX == gridY)
			{
				if (macroBoard[(gridX + 1) % 3][(gridY + 1) % 3] == opponent)
					score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
				if (macroBoard[(gridX + 1) % 3][(gridY + 1) % 3] == player)
					score += opponent == 1 ? scorePerGrid : -scorePerGrid;

				if (macroBoard[(gridX + 2) % 3][(gridY + 2) % 3] == opponent)
					score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
				if (macroBoard[(gridX + 2) % 3][(gridY + 2) % 3] == player)
					score += opponent == 1 ? scorePerGrid : -scorePerGrid;
			}
			if (gridX == 2 - gridY)
			{
				if (macroBoard[(gridX + 2) % 3][(gridY + 1) % 3] == opponent)
					score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
				if (macroBoard[(gridX + 2) % 3][(gridY + 1) % 3] == player)
					score += opponent == 1 ? scorePerGrid : -scorePerGrid;

				if (macroBoard[(gridX + 1) % 3][(gridY + 2) % 3] == opponent)
					score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
				if (macroBoard[(gridX + 1) % 3][(gridY + 2) % 3] == player)
					score += opponent == 1 ? scorePerGrid : -scorePerGrid;
			}
		}
		else {

			if (macroBoard[(gridX + 1) % 3][gridY] != opponent && macroBoard[(gridX + 2) % 3][gridY] != opponent &&
				macroBoard[(gridX + 1) % 3][gridY] != 3 && macroBoard[(gridX + 2) % 3][gridY] != 3)
			{
				score += player == 1 ? scorePerGrid : -scorePerGrid;
			}
			else if (macroBoard[(gridX + 1) % 3][gridY] != player && macroBoard[(gridX + 2) % 3][gridY] != player)
			{
				if (macroBoard[(gridX + 1) % 3][gridY] == opponent)
					score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
				if (macroBoard[(gridX + 2) % 3][gridY] == opponent)
					score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
			}

			if (macroBoard[gridX][(gridY + 1) % 3] != opponent && macroBoard[gridX][(gridY + 2) % 3] != opponent &&
				macroBoard[gridX][(gridY + 1) % 3] != 3 && macroBoard[gridX][(gridY + 2) % 3] != 3)
			{
				score += player == 1 ? scorePerGrid : -scorePerGrid;
			}
			else if (macroBoard[gridX][(gridY + 1) % 3] != player && macroBoard[gridX][(gridY + 2) % 3] != player)
			{
				if (macroBoard[gridX][(gridY + 1) % 3] == opponent)
					score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
				if (macroBoard[gridX][(gridY + 2) % 3] == opponent)
					score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
			}

			if (gridX == gridY)
			{
				if (macroBoard[(gridX + 1) % 3][(gridY + 1) % 3] != opponent && macroBoard[(gridX + 2) % 3][(gridY + 2) % 3] != opponent &&
					macroBoard[(gridX + 1) % 3][(gridY + 1) % 3] != 3 && macroBoard[(gridX + 2) % 3][(gridY + 2) % 3] != 3)
				{
					score += player == 1 ? scorePerGrid : -scorePerGrid;
				}
				else if (macroBoard[(gridX + 1) % 3][(gridY + 1) % 3] != player && macroBoard[(gridX + 2) % 3][(gridY + 2) % 3] != player)
				{
					if (macroBoard[(gridX + 1) % 3][(gridY + 1) % 3] == opponent)
						score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
					if (macroBoard[(gridX + 2) % 3][(gridY + 2) % 3] == opponent)
						score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
				}
			}

			if (gridX == 2 - gridY)
			{
				if (macroBoard[(gridX + 2) % 3][(gridY + 1) % 3] != opponent && macroBoard[(gridX + 1) % 3][(gridY + 2) % 3] != opponent &&
					macroBoard[(gridX + 2) % 3][(gridY + 1) % 3] != 3 && macroBoard[(gridX + 1) % 3][(gridY + 2) % 3] != 3)
				{
					score += player == 1 ? scorePerGrid : -scorePerGrid;
				}
				else if (macroBoard[(gridX + 2) % 3][(gridY + 1) % 3] != player && macroBoard[(gridX + 1) % 3][(gridY + 2) % 3] != player)
				{
					if (macroBoard[(gridX + 2) % 3][(gridY + 1) % 3] == opponent)
						score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
					if (macroBoard[(gridX + 1) % 3][(gridY + 2) % 3] == opponent)
						score -= opponent == 1 ? scorePerGrid : -scorePerGrid;
				}
			}
		}
	}
	if (winner == 0)
	{
		if (macroBoard[gridX][gridY] <= 0)
		{
			if (field[gridX][gridY][(x + 1) % 3][y] != opponent && field[gridX][gridY][(x + 2) % 3][y] != opponent)
			{
				score += player == 1 ? 1 : -1;
			}
			else if (field[gridX][gridY][(x + 1) % 3][y] != player && field[gridX][gridY][(x + 2) % 3][y] != player)
			{
				if (field[gridX][gridY][(x + 1) % 3][y] == opponent)
					score -= opponent == 1 ? 1 : -1;
				if (field[gridX][gridY][(x + 2) % 3][y] == opponent)
					score -= opponent == 1 ? 1 : -1;
			}

			if (field[gridX][gridY][x][(y + 1) % 3] != opponent && field[gridX][gridY][x][(y + 2) % 3] != opponent)
			{
				score += player == 1 ? 1 : -1;
			}
			else if (field[gridX][gridY][x][(y + 1) % 3] != player && field[gridX][gridY][x][(y + 2) % 3] != player)
			{
				if (field[gridX][gridY][x][(y + 1) % 3] == opponent)
					score -= opponent == 1 ? 1 : -1;
				if (field[gridX][gridY][x][(y + 2) % 3] == opponent)
					score -= opponent == 1 ? 1 : -1;
			}

			if (x == y)
			{
				if (field[gridX][gridY][(x + 1) % 3][(y + 1) % 3] != opponent && field[gridX][gridY][(x + 2) % 3][(y + 2) % 3] != opponent)
				{
					score += player == 1 ? 1 : -1;
				}
				else if (field[gridX][gridY][(x + 1) % 3][(y + 1) % 3] != player && field[gridX][gridY][(x + 2) % 3][(y + 2) % 3] != player)
				{
					if (field[gridX][gridY][(x + 1) % 3][(y + 1) % 3] == opponent)
						score -= opponent == 1 ? 1 : -1;
					if (field[gridX][gridY][(x + 2) % 3][(y + 2) % 3] == opponent)
						score -= opponent == 1 ? 1 : -1;
				}
			}

			if (x == 2 - y)
			{
				if (field[gridX][gridY][(x + 2) % 3][(y + 1) % 3] != opponent && field[gridX][gridY][(x + 1) % 3][(y + 2) % 3] != opponent)
				{
					score += player == 1 ? 1 : -1;
				}
				else if (field[gridX][gridY][(x + 2) % 3][(y + 1) % 3] != player && field[gridX][gridY][(x + 1) % 3][(y + 2) % 3] != player)
				{
					if (field[gridX][gridY][(x + 2) % 3][(y + 1) % 3] == opponent)
						score -= opponent == 1 ? 1 : -1;
					if (field[gridX][gridY][(x + 1) % 3][(y + 2) % 3] == opponent)
						score -= opponent == 1 ? 1 : -1;
				}
			}
		}

		bool openBoard = false;
		if (macroBoard[x][y] > 0)
			openBoard = true;
		moveCount = 0;
		for (int newGridY = 0; newGridY < 3; ++newGridY)
		{
			for (int newGridX = 0; newGridX < 3; ++newGridX)
			{
				if (macroBoard[newGridX][newGridY] <= 0)
				{
					macroBoard[newGridX][newGridY] = openBoard ? -1 : 0;
					if (newGridX == x && newGridY == y)
						macroBoard[newGridX][newGridY] = -1;
				}
				if (macroBoard[newGridX][newGridY] == -1)
				{
					for (int newY = 0; newY < 3; ++newY)
					{
						for (int newX = 0; newX < 3; ++newX)
						{
							if (field[newGridX][newGridY][newX][newY] == 0)
							{
								moveCount++;
							}
						}
					}
				}
			}
		}
	}
	return;
}

void board::evaluateMacroboard(int gridX, int gridY, int x, int y)
{
	//Search adjacent spaces to see if grid has been won
	int player = field[gridX][gridY][x][y];
	if (player == 0)
		return;
	if (field[gridX][gridY][(x + 1) % 3][y] == player &&
	    field[gridX][gridY][(x + 2) % 3][y] == player)
		macroBoard[gridX][gridY] = player;
	else if (field[gridX][gridY][x][(y + 1) % 3] == player &&
	         field[gridX][gridY][x][(y + 2) % 3] == player)
		macroBoard[gridX][gridY] = player;
	else if (x == y &&
	         field[gridX][gridY][(x + 1) % 3][(y + 1) % 3] == player &&
	         field[gridX][gridY][(x + 2) % 3][(y + 2) % 3] == player)
		macroBoard[gridX][gridY] = player;
	else if (x == 2 - y &&
	         field[gridX][gridY][(x + 2) % 3][(y + 1) % 3] == player &&
	         field[gridX][gridY][(x + 1) % 3][(y + 2) % 3] == player)
		macroBoard[gridX][gridY] = player;
	else
	{
		macroBoard[gridX][gridY] = 3; //Assume grid is tied until an open space is found
		for (int fieldY = 0; fieldY < 3; ++fieldY)
		{
			for (int fieldX = 0; fieldX < 3; ++fieldX)
			{
				if (field[gridX][gridY][fieldX][fieldY] == 0)
				{
					macroBoard[gridX][gridY] = 0;
					return;
				}
			}
		}
	}
	return;
}

void board::evaluateWinner(int gridX, int gridY)
{
	int player = macroBoard[gridX][gridY];
	if (winner != 0 || (player != 1 && player != 2))
	{
		return;
	}
	if (macroBoard[(gridX + 1) % 3][gridY] == player &&
	    macroBoard[(gridX + 2) % 3][gridY] == player)
		winner = player;
	else if (macroBoard[gridX][(gridY + 1) % 3] == player &&
		     macroBoard[gridX][(gridY + 2) % 3] == player)
		winner = player;
	else if (gridX == gridY &&
	         macroBoard[(gridX + 1) % 3][(gridY + 1) % 3] == player &&
	         macroBoard[(gridX + 2) % 3][(gridY + 2) % 3] == player)
		winner = player;
	else if (gridX == 2 - gridY &&
	         macroBoard[(gridX + 2) % 3][(gridY + 1) % 3] == player &&
	         macroBoard[(gridX + 1) % 3][(gridY + 2) % 3] == player)
		winner = player;
	else
	{
		winner = 3; //Assume game is tied until an open grid is found
		for (gridY = 0; gridY < 3; ++gridY)
		{
			for (gridX = 0; gridX < 3; ++gridX)
			{
				if (macroBoard[gridX][gridY] <= 0)
				{
					winner = 0;
					return;
				}
			}
		}
	}
	return;
}

void board::evaluateScore()
{
	score = 0;
	for (int gridY = 0; gridY < 3; ++gridY)
	{
		for (int gridX = 0; gridX < 3; ++gridX)
		{
			if (macroBoard[gridX][gridY] == 1)
			{
				if (macroBoard[(gridX + 1) % 3][gridY] != 2 && macroBoard[(gridX + 2) % 3][gridY] != 2 &&
					macroBoard[(gridX + 1) % 3][gridY] != 3 && macroBoard[(gridX + 2) % 3][gridY] != 3)
				{
					score += scorePerGrid;
				}

				if (macroBoard[gridX][(gridY + 1) % 3] != 2 && macroBoard[gridX][(gridY + 2) % 3] != 2 &&
					macroBoard[gridX][(gridY + 1) % 3] != 3 && macroBoard[gridX][(gridY + 2) % 3] != 3)
				{
					score += scorePerGrid;
				}

				if (gridX == gridY && macroBoard[(gridX + 1) % 3][(gridY + 1) % 3] != 2 && macroBoard[(gridX + 2) % 3][(gridY + 2) % 3] != 2 &&
					gridX == gridY && macroBoard[(gridX + 1) % 3][(gridY + 1) % 3] != 3 && macroBoard[(gridX + 2) % 3][(gridY + 2) % 3] != 3)
				{
					score += scorePerGrid;
				}

				if (gridX == 2 - gridY && macroBoard[(gridX + 2) % 3][(gridY + 1) % 3] != 2 && macroBoard[(gridX + 1) % 3][(gridY + 2) % 3] != 2 &&
					gridX == 2 - gridY && macroBoard[(gridX + 2) % 3][(gridY + 1) % 3] != 3 && macroBoard[(gridX + 1) % 3][(gridY + 2) % 3] != 3)
				{
					score += scorePerGrid;
				}
			}
			else if (macroBoard[gridX][gridY] == 2)
			{
				if (macroBoard[(gridX + 1) % 3][gridY] != 1 && macroBoard[(gridX + 2) % 3][gridY] != 1 &&
					macroBoard[(gridX + 1) % 3][gridY] != 3 && macroBoard[(gridX + 2) % 3][gridY] != 3)
				{
					score -= scorePerGrid;
				}

				if (macroBoard[gridX][(gridY + 1) % 3] != 1 && macroBoard[gridX][(gridY + 2) % 3] != 1 &&
					macroBoard[gridX][(gridY + 1) % 3] != 3 && macroBoard[gridX][(gridY + 2) % 3] != 3)
				{
					score -= scorePerGrid;
				}

				if (gridX == gridY && macroBoard[(gridX + 1) % 3][(gridY + 1) % 3] != 1 && macroBoard[(gridX + 2) % 3][(gridY + 2) % 3] != 1 &&
					gridX == gridY && macroBoard[(gridX + 1) % 3][(gridY + 1) % 3] != 3 && macroBoard[(gridX + 2) % 3][(gridY + 2) % 3] != 3)
				{
					score -= scorePerGrid;
				}

				if (gridX == 2 - gridY && macroBoard[(gridX + 2) % 3][(gridY + 1) % 3] != 1 && macroBoard[(gridX + 1) % 3][(gridY + 2) % 3] != 1 &&
					gridX == 2 - gridY && macroBoard[(gridX + 2) % 3][(gridY + 1) % 3] != 3 && macroBoard[(gridX + 1) % 3][(gridY + 2) % 3] != 3)
				{
					score -= scorePerGrid;
				}
			}
			else if (macroBoard[gridX][gridY] <= 0)
			{
				for (int y = 0; y < 3; ++y)
				{
					for (int x = 0; x < 3; ++x)
					{
						if (field[gridX][gridY][x][y] == 1)
						{
							if (field[gridX][gridY][(x + 1) % 3][y] != 2 && field[gridX][gridY][(x + 2) % 3][y] != 2)
							{
								score++;
							}

							if (field[gridX][gridY][x][(y + 1) % 3] != 2 && field[gridX][gridY][x][(y + 2) % 3] != 2)
							{
								score++;
							}

							if (x == y && field[gridX][gridY][(x + 1) % 3][(y + 1) % 3] != 2 && field[gridX][gridY][(x + 2) % 3][(y + 2) % 3] != 2)
							{
								score++;
							}

							if (x == 2 - y && field[gridX][gridY][(x + 2) % 3][(y + 1) % 3] != 2 && field[gridX][gridY][(x + 1) % 3][(y + 2) % 3] != 2)
							{
								score++;
							}
						}
						else if (field[gridX][gridY][x][y] == 2)
						{
							if (field[gridX][gridY][(x + 1) % 3][y] != 1 && field[gridX][gridY][(x + 2) % 3][y] != 1)
							{
								score--;
							}

							if (field[gridX][gridY][x][(y + 1) % 3] != 1 && field[gridX][gridY][x][(y + 2) % 3] != 1)
							{
								score--;
							}

							if (x == y && field[gridX][gridY][(x + 1) % 3][(y + 1) % 3] != 1 && field[gridX][gridY][(x + 2) % 3][(y + 2) % 3] != 1)
							{
								score--;
							}

							if (x == 2 - y && field[gridX][gridY][(x + 2) % 3][(y + 1) % 3] != 1 && field[gridX][gridY][(x + 1) % 3][(y + 2) % 3] != 1)
							{
								score--;
							}
						}
					}
				}
			}
		}
	}
}

int board::evaluateMoveCount()
{
	moveCount = 0;
	for (int gridY = 0; gridY < 3; ++gridY)
	{
		for (int gridX = 0; gridX < 3; ++gridX)
		{
			if (macroBoard[gridX][gridY] == -1)
			{
				for (int y = 0; y < 3; ++y)
				{
					for (int x = 0; x < 3; ++x)
					{
						if (field[gridX][gridY][x][y] == 0)
						{
							moveCount++;
						}
					}
				}
			}
		}
	}
	return moveCount;
}

int board::getScore(int player)
{
	return player == 1 ? score : -score;
}

int alphaBeta(board* b, int player, bool maximizing, int alpha, int beta, int* count)
{
	int opponent = getOpponent(player);
	int scorePlayer = maximizing ? player : opponent;
	if (b->getWinner() != 0)
	{
		(*count)--;
		return (b->getWinner() == scorePlayer ? INT_MAX : INT_MIN);
	}
	int moveCount = b->getMoveCount();
	if (moveCount > (*count)) 
	{
		(*count)--;
		return b->getScore(scorePlayer);
	}
	int remainingMoves = moveCount;
	int bestScore = maximizing ? INT_MIN : INT_MAX;

	for (int gridY = 0; gridY < 3; ++gridY)
	{
		for (int gridX = 0; gridX < 3; ++gridX)
		{
			if (b->macroBoard[gridX][gridY] == -1)
			{
				for (int y = 0; y < 3; ++y)
				{
					for (int x = 0; x < 3; ++x)
					{
						if (b->field[gridX][gridY][x][y] == 0)
						{
							board* newBoard = b->copy();
							newBoard->play_move(player, 3 * gridX + x, 3 * gridY + y);

							int newCount = (*count) / remainingMoves;
							remainingMoves--;
							(*count) -= newCount;
							int score = alphaBeta(newBoard, opponent, !maximizing, alpha, beta, &newCount);
							(*count) += newCount;

							delete newBoard;

							if (maximizing)
							{
								bestScore = max(bestScore, score);
								alpha = max(alpha, bestScore);
							}
							else {
								bestScore = min(bestScore, score);
								beta = min(beta, bestScore);
							}
							if (beta <= alpha)
								return beta;
						}
					}
				}
			}
		}
	}
	return bestScore;
}

int main()
{
	int max_timebank = 0;
	int time_per_move = 0;
	char player_names[16];
	char your_bot[8];
	int your_botid = 0;
	scanf("settings timebank %i\n", &max_timebank);
	scanf("settings time_per_move %i\n", &time_per_move);
	scanf("settings player_names %s\n", player_names);
	scanf("settings your_bot %s\n", your_bot);
	scanf("settings your_botid %i\n", &your_botid);


	board* b = new board();
	int round = 0;
	int move = 0;
	int timebank = 0;
	int nodesPerMs = -1;
	float usedRatio = 1.0f;
	while (1)
	{
		scanf("update game round %i\n", &round);
		scanf("update game move %i\n", &move);
		scanf("update game field ");
		for (int gridY = 0; gridY < 3; ++gridY)
		{
			for (int y = 0; y < 3; ++y)
			{
				for (int gridX = 0; gridX < 3; ++gridX)
				{
					for (int x = 0; x < 3; ++x)
					{
						scanf("%i,", &(b->field[gridX][gridY][x][y]));
					}
				}
			}
		}
		scanf("\nupdate game macroboard ");
		for (int gridY = 0; gridY < 3; ++gridY)
		{
			for (int gridX = 0; gridX < 3; ++gridX)
			{
				scanf("%i,", &(b->macroBoard[gridX][gridY]));
			}
		}
		scanf("\naction move %i", &timebank);
		if (move == 1)
		{
			cout << "place_move 4 4" << endl;
		} else {
			b->evaluateMoveCount();

			if (nodesPerMs <= 0)
			{
				int count = 0;
				int start_time = clock();
				do {
					int testCount = 1000;
					alphaBeta(b, your_botid, true, INT_MIN, INT_MAX, &testCount);
					count += (1000 - testCount);
				} while ((double)(clock() - start_time) / (CLOCKS_PER_SEC / 1000.0) < 200);
				nodesPerMs = count / 200;
			}


			int allocatedTime = 750;
			if (round > 17)
			{
				allocatedTime = timebank / 2;
			}
			int count = (int)((nodesPerMs * allocatedTime / max(usedRatio,0.01f)));
			if (count < 0)
				count = INT_MAX;
			int start_count = count;
			cerr << "Allocating " << count << " nodes to be searched in " << allocatedTime << " ms." << endl;
			int start_time = clock();

			int best_score = INT_MIN;
			int best_index_x = -1;
			int best_index_y = -1;
			for (int gridY = 0; gridY < 3; ++gridY)
			{
				for (int y = 0; y < 3; ++y)
				{
					for (int gridX = 0; gridX < 3; ++gridX)
					{
						for (int x = 0; x < 3; ++x)
						{
							if (b->macroBoard[gridX][gridY] == -1 && b->field[gridX][gridY][x][y] == 0)
							{
								if (best_index_x == -1)
								{
									best_index_x = 3 * gridX + x;
									best_index_y = 3 * gridY + y;
								}
								board* newBoard = b->copy();
								newBoard->play_move(your_botid, 3 * gridX + x, 3 * gridY + y);
								int newCount = count / b->getMoveCount();
								count -= newCount;
								int newScore = alphaBeta(newBoard, getOpponent(your_botid), false, best_score, INT_MAX, &newCount);
								count += newCount;
								delete newBoard;
								if (newScore > best_score)
								{
									best_score = newScore;
									best_index_x = 3 * gridX + x;
									best_index_y = 3 * gridY + y;
								}
								cerr << newScore << " (" << (clock() - start_time) / (CLOCKS_PER_SEC / 1000) << "ms)";
							}
							else {
								cerr << "[ " << b->field[gridX][gridY][x][y] << " ]";
							}
							cerr << " ";
						}
						cerr << " ";
					}
					cerr << endl;
				}
				cerr << endl;
			}
			int stop_time = clock();
			int actualTime = max((int)((stop_time - start_time) / (CLOCKS_PER_SEC / 1000)), 1);
			int usedCount = start_count - count;
			usedRatio = (float)usedCount / start_count;
			nodesPerMs = usedCount / actualTime;

			cout << "place_move " << best_index_x << " " << best_index_y << endl;
			cerr << "Found score " << best_score << " in " << actualTime << " ms (" << usedRatio * 100 << " %) with " << start_count - count << " nodes." << endl;
			
		}
		scanf("\n");
	}

	while (1);
}